
basCal
======

Functions
------------
- Displays user generated events inside a datagrid
- Displays the latest event inside a listbox
- Users can create new events via the right hand side "charms menu"
- Existing events can be can be modified inside the upcoming events listbox 

Note. The Silverlight client and the WCF service have to be started from Visual Studio.

Personal notes
-----------------
- GridCell highlighting can be enabled in UserControl.Resources styles